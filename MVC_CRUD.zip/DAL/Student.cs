﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DAL
{
    public class Student
    {
        string conStr = ConfigurationManager.ConnectionStrings["connection"].ConnectionString;

        public DataTable GetState()
        {
            DataTable dt = new DataTable();
            using (SqlConnection cn = new SqlConnection(conStr))
            {
                try
                {
                    SqlCommand cmd = new SqlCommand("prc_GetState", cn);
                    cmd.CommandType = CommandType.StoredProcedure;
                    SqlDataAdapter da = new SqlDataAdapter(cmd);
                    da.Fill(dt);
                }
                catch (Exception ex)
                {
                    string str = ex.Message.ToString();
                }
            }
            return dt;

        }

        public void InsertStudent(BO.Student objStudent)
        {
            int i = 0;

            using(SqlConnection cn = new SqlConnection(conStr))
            {
                using(SqlCommand cmd = new SqlCommand("prc_InsertStudent", cn))
                {
                    cmd.CommandType = CommandType.StoredProcedure;

                    cmd.Parameters.Add("@DepartmentID ", SqlDbType.Int, 0).Value = objStudent.DepartmentID;
                    cmd.Parameters.Add("@FName", SqlDbType.VarChar, 500).Value = objStudent.FName;
                    cmd.Parameters.Add("@LName", SqlDbType.VarChar, 500).Value = objStudent.LName;
                    cmd.Parameters.Add("@DOB", SqlDbType.DateTime).Value = objStudent.DOB;
                    cmd.Parameters.Add("@Email", SqlDbType.VarChar, 500).Value = objStudent.Email;
                    cmd.Parameters.Add("@Phone", SqlDbType.VarChar, 500).Value = objStudent.Phone;
                    cmd.Parameters.Add("@Gender", SqlDbType.VarChar, 10).Value = objStudent.Gender;
                    cmd.Parameters.Add("@Address", SqlDbType.VarChar).Value = objStudent.Address;
                    cmd.Parameters.Add("@CityID", SqlDbType.Int).Value = objStudent.CityID;
                    cmd.Parameters.Add("@StateID", SqlDbType.Int).Value = objStudent.StateID;
                    cmd.Parameters.Add("@UniversityName", SqlDbType.VarChar, 500).Value = objStudent.UniversityName;
                    cmd.Parameters.Add("@Hobbies", SqlDbType.VarChar, 500).Value = objStudent.Hobbies;
                    cmd.Parameters.Add("@CreatedBy", SqlDbType.VarChar, 10).Value = "Nandkishor Yadav";
                    cmd.Parameters.Add("@ModifiedBy", SqlDbType.VarChar, 10).Value = "";
                    cmd.Parameters.Add("@ProfilePicturePath", SqlDbType.VarChar).Value = objStudent.ProfilePicPath;
                    cmd.Parameters.Add("@ResumePath", SqlDbType.VarChar).Value = objStudent.ResumePath;
                    cmd.Parameters.Add("@ProfilePictureName", SqlDbType.VarChar, 500).Value = objStudent.ProfilePicName;
                    cmd.Parameters.Add("@ResumeName", SqlDbType.VarChar, 500).Value = objStudent.ResumeName;

                    try
                    {
                        cn.Open(); 
                       i= cmd.ExecuteNonQuery();
                        cn.Close();

                    }
                    catch(Exception ex)
                    {
                        string str = ex.Message;
                    }
                    finally
                    {
                        if (cn.State == ConnectionState.Open)
                            cn.Close();

                    }

                }
            }
        }
    }
}
