﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web;
using System.Web.Mvc;

namespace BO
{
   public class Student
    {
        public Student()
        {
            //lststate = new list<selectlistitem>();
            //lstdepartment = new list<selectlistitem>();

            Hoby.Add(new SelectListItem { Text = "Swiming", Value = "Swiming" });
            Hoby.Add(new SelectListItem { Text = "Coding", Value = "Coding" });
            Hoby.Add(new SelectListItem { Text = "Sleeping", Value = "Sleeping" });
            Hoby.Add(new SelectListItem { Text = "Playing", Value = "Playing" });

        }
        public int StudentID { get; set; }
        public int DepartmentID { get; set; }
        public string FName { get; set; }
        public string LName { get; set; }

        public DateTime DOB { get; set; }
        public string Email { get; set; }
        public string Phone { get; set; }
        public string Gender { get; set; }
        public string Address { get; set; }
        public int CityID { get; set; }
        public int StateID { get; set; }
        public string UniversityName { get; set; }
        public string Hobbies { get; set; }
        public string ProfilePicPath { get; set; }
        public string ResumePath { get; set; }

        public string ProfilePicName { get; set; }
        public string ResumeName { get; set; }

        public HttpPostedFileBase Image_File { get; set; }

        public HttpPostedFileBase Resume_File { get; set; }

        public List<SelectListItem> lstState { get; set; } = new List<SelectListItem>();
        public List<SelectListItem> lstDepartment { get; set; } = new List<SelectListItem>();

        public List<SelectListItem> Hoby { get; set; } = new List<SelectListItem>();

    }
}
