﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DAL;
using BO;
using System.Data;

namespace BL
{
    public class Student
    {
        public DataTable GetState()
        {
            DataTable dt = new DataTable();
            DAL.Student objStudent = new DAL.Student();
            dt= objStudent.GetState();

            return dt;
        }

        public void InsertStudent(BO.Student objStudent)
        {
            DAL.Student obj = new DAL.Student();
            obj.InsertStudent(objStudent);
        }
    }
}
